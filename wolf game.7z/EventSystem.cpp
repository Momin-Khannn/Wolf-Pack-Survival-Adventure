#include "EventSystem.h"

void EventPriorityQueue::push(GameEvent event) {
    // 1. Add to the end of the list
    heap.push_back(event);
    
    // 2. Move it UP to its correct spot (Bubble Up)
    heapifyUp(heap.size() - 1);
}

GameEvent EventPriorityQueue::pop() {
    if (isEmpty()) return GameEvent("None", "", 999, 0, 0);

    // 1. Save the top item (Highest Priority)
    GameEvent result = heap[0];

    // 2. Move the last item to the root
    heap[0] = heap.back();
    heap.pop_back();

    // 3. Move it DOWN to its correct spot (Bubble Down)
    if (!isEmpty()) {
        heapifyDown(0);
    }

    return result;
}

void EventPriorityQueue::heapifyUp(int i) {
    // If current node is smaller (higher priority) than parent, swap them
    // Example: Priority 1 is "smaller" number than Priority 3
    while (i > 0 && heap[i].priority < heap[parent(i)].priority) {
        std::swap(heap[i], heap[parent(i)]);
        i = parent(i);
    }
}

void EventPriorityQueue::heapifyDown(int i) {
    int smallest = i;
    int l = leftChild(i);
    int r = rightChild(i);

    // Check if left child exists and has higher priority (smaller number)
    if (l < heap.size() && heap[l].priority < heap[smallest].priority)
        smallest = l;

    // Check if right child exists and has higher priority
    if (r < heap.size() && heap[r].priority < heap[smallest].priority)
        smallest = r;

    // If smallest is not current, swap and continue
    if (smallest != i) {
        std::swap(heap[i], heap[smallest]);
        heapifyDown(smallest);
    }
}

bool EventPriorityQueue::isEmpty() {
    return heap.empty();
}

GameEvent EventPriorityQueue::peek() {
    if (!isEmpty()) return heap[0];
    return GameEvent("None", "", 999, 0, 0);
}
int EventPriorityQueue::size() {
    return heap.size();
}