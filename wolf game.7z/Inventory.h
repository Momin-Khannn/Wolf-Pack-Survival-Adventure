#ifndef INVENTORY_H
#define INVENTORY_H

#include "GameData.h"
#include <iostream>
#include <vector>

struct InventoryNode {
    Item data;
    InventoryNode* next;
    InventoryNode(Item item) : data(item), next(nullptr) {}
};

class InventoryList {
private:
    InventoryNode* head;
    int itemCount;
    const int MAX_ITEMS = 10; 

public:
    InventoryList(); 
    ~InventoryList(); 

    bool addItem(Item newItem);                 
    bool useItem(std::string itemName, WolfStats& stats); 
    void removeItem(std::string itemName);      
    
    void displayInventory() const;              
    bool hasItem(std::string itemName) const;   
    bool isFull() const;                        
    
    std::vector<Item> toVector() const;
};

#endif