#include "GameEngine.h"
#include <iostream>
#include <cstdlib> // for system("cls") and rand()
#include <iomanip> // For nice formatting

// ==========================================
// SETUP
// ==========================================
void GameEngine::initGame() {
    currentStats = {100, 0, 100, 0}; // Health, Hunger, Energy, Rep
    
    // BUILD STORY
    addNode(1, "LEVEL 1 - Frozen Awakening\n\nCold bites into your fur. You wake up alone. The pack is gone.\nSilence surrounds you. You must act quickly to survive.");
    addNode(2, "LEVEL 2 - The Cave\n\nYou find a small cave. It is cold, but protects you from the wind.");
    addNode(3, "LEVEL 2 - The Hunt\n\nYou spot a rabbit track. Tracking it will take energy, but you need food.");
    addNode(99, "GAME OVER - You collapsed from exhaustion.");

    connect(1, "Search for Shelter (Safe)", 2);
    connect(1, "Search for Food (Risk)", 3);
    connect(2, "Rest and Sleep (+Energy)", 1); 
    connect(3, "Chase the rabbit (-Energy, +Food)", 1); 

    currentNode = storyMap[1];
    Item starterMeat("Scraps", FOOD, 10, 1);
    inventory.addItem(starterMeat);
    
    addNotification("Game Started.");
}

// ==========================================
// CORE LOGIC & UNDO SYSTEM
// ==========================================
void GameEngine::saveState() {
    GameState snapshot;
    snapshot.nodeId = currentNode->id;
    snapshot.stats = currentStats;
    historyStack.push(snapshot); // Saved to Stack
}

void GameEngine::undoLastAction() {
    if (historyStack.empty()) {
        addNotification("Cannot Undo. Start of history.");
        return;
    }

    // 1. Get previous state
    GameState lastState = historyStack.top();
    historyStack.pop();

    // 2. Restore it
    if (storyMap.find(lastState.nodeId) != storyMap.end()) {
        currentNode = storyMap[lastState.nodeId];
        currentStats = lastState.stats;
        addNotification("Time Rewind Successful.");
    }
}

void GameEngine::makeChoice(int choiceIndex) {
    if (choiceIndex < 0 || choiceIndex >= currentNode->children.size()) return;

    // SAVE STATE BEFORE MOVING (For Undo)
    saveState();

    int nextNodeID = currentNode->children[choiceIndex].second;
    
    // Logic
    currentStats.hunger += 10;
    currentStats.energy -= 5;
    
    if (currentStats.health <= 0 || currentStats.hunger >= 100) {
        gameOver = true;
        nextNodeID = 99;
    }

    if (storyMap.find(nextNodeID) != storyMap.end()) {
        currentNode = storyMap[nextNodeID];
    }
    
    triggerRandomEvent();
}

// ==========================================
// THE NEW "PROFESSIONAL" GUI (CONSOLE FALLBACK)
// ==========================================
void GameEngine::runConsoleGame() {
    while (!gameOver) {
        system("cls"); 
        
        // --- TOP SECTION: STATS ---
        std::cout << "=================================================================\n";
        std::cout << " HEALTH: " << std::left << std::setw(5) << currentStats.health 
                  << " | HUNGER: " << std::setw(5) << currentStats.hunger 
                  << " | ENERGY: " << std::setw(5) << currentStats.energy << "\n";
        std::cout << "=================================================================\n";

        // --- MIDDLE SECTION: STORY ---
        std::cout << "\n" << currentNode->text << "\n\n";

        // --- SIDE PANEL: RECENT EVENTS (Bottom for Console) ---
        std::cout << "--- NOTIFICATION LOG ---\n";
        int startLog = (notificationLog.size() > 3) ? notificationLog.size() - 3 : 0;
        for (int i = startLog; i < notificationLog.size(); i++) {
            std::cout << " > " << notificationLog[i] << "\n";
        }
        std::cout << "------------------------\n\n";

        // --- CHOICE SECTION ---
        std::cout << "OPTIONS:\n";
        for (size_t i = 0; i < currentNode->children.size(); i++) {
            std::cout << " [" << (i + 1) << "] " << currentNode->children[i].first << "\n";
        }
        
        // --- GAME CONTROLS ---
        std::cout << "\n-----------------------------------------------------------------\n";
        std::cout << " [I] Inventory   [U] Undo Last Move   [Q] Quit\n";
        std::cout << "-----------------------------------------------------------------\n";
        std::cout << " ENTER ACTION > ";

        char input;
        std::cin >> input;

        if (input == 'q' || input == 'Q') break;
        else if (input == 'u' || input == 'U') undoLastAction();
        else if (input == 'i' || input == 'I') {
            std::cout << "\nINVENTORY:\n";
            inventory.displayInventory();
            system("pause");
        }
        else if (isdigit(input)) {
            int choice = input - '1'; 
            makeChoice(choice);
        }
    }
}

// ==========================================
// HELPERS
// ==========================================
void GameEngine::addNotification(std::string msg) {
    notificationLog.push_back(msg);
}

void GameEngine::triggerRandomEvent() {
    int roll = rand() % 100;
    if (roll < 20) {
        eventQueue.push(GameEvent("Sudden Wind", "It gets colder.", 3, 0, -5));
        addNotification("Event: Sudden Wind (Energy -5)"); // Update Side Panel
    }
    
    if (!eventQueue.isEmpty()) {
        GameEvent e = eventQueue.pop();
        currentStats.energy += e.energyEffect;
    }
}

void GameEngine::addNode(int id, std::string text) {
    storyMap[id] = new StoryNode(id, text);
}
void GameEngine::connect(int parentID, std::string choiceText, int childID) {
    storyMap[parentID]->children.push_back({ choiceText, childID });
}
void GameEngine::useItem(int itemIndex) {
    std::vector<Item> items = inventory.toVector();
    if (itemIndex >= 0 && itemIndex < items.size()) {
        inventory.useItem(items[itemIndex].name, currentStats);
    }
}

// ==========================================
// GUI HELPER (REQUIRED FOR GUI.CPP)
// ==========================================
std::string GameEngine::getFinalTitle() {
    if (currentStats.reputation >= 20) return "Alpha of the North";
    if (currentStats.reputation >= 10) return "Respected Leader";
    if (currentStats.reputation < 0) return "The Outcast";
    return "Lone Survivor";
}