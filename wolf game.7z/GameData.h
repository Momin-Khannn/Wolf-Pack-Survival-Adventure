#ifndef GAMEDATA_H
#define GAMEDATA_H

#include <string>
#include <vector>
#include <iostream>

// ==========================================
// SHARED ENUMS
// ==========================================
enum ItemType { FOOD, HERB, TOOL, WEAPON };

// ==========================================
// CORE STRUCTS
// ==========================================

// 1. WOLF STATS
struct WolfStats {
    int health = 100;
    int hunger = 0;
    int energy = 100;
    int reputation = 0;
    int dayCount = 1;
};

// 2. ITEM DEFINITION
struct Item {
    std::string name;
    ItemType type;
    int effectValue;
    int quantity;

    Item(std::string n, ItemType t, int e, int q)
        : name(n), type(t), effectValue(e), quantity(q) {}
    Item() {}
};

// 3. STORY NODE
// Pair<ButtonText, NextNodeID>
typedef std::pair<std::string, int> Option;

struct StoryNode {
    int id;
    std::string text; 

    // Stats changes (Optional for now)
    int healthChange = 0;
    int energyChange = 0;
    int hungerChange = 0;
    int reputationChange = 0;

    std::vector<Option> children; // Choices leading to other nodes

    StoryNode(int _id, std::string _text) : id(_id), text(_text) {}
    StoryNode() {}
};

#endif