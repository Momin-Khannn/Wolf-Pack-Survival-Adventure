#ifndef EVENTSYSTEM_H
#define EVENTSYSTEM_H

#include <string>
#include <vector>
#include <iostream>

// Structure for a Game Event
struct GameEvent {
    std::string title;
    std::string description;
    int priority; // 1 = Critical (Bear), 2 = Urgent, 3 = Normal (Weather)
    
    // Impact on stats
    int healthEffect = 0;
    int energyEffect = 0;

    GameEvent(std::string t, std::string d, int p, int h, int e)
        : title(t), description(d), priority(p), healthEffect(h), energyEffect(e) {}
    GameEvent() {}
};

class EventPriorityQueue {
private:
    std::vector<GameEvent> heap;

    // Helper functions for Heap Logic
    int parent(int i) { return (i - 1) / 2; }
    int leftChild(int i) { return (2 * i) + 1; }
    int rightChild(int i) { return (2 * i) + 2; }
    void heapifyDown(int i);
    void heapifyUp(int i);

public:
    void push(GameEvent event); // Add event
    GameEvent pop();            // Remove highest priority event
    GameEvent peek();           // Look at top event
    bool isEmpty();
    int size();
};

#endif