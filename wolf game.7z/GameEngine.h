#ifndef GAMEENGINE_H
#define GAMEENGINE_H

#include "GameData.h"
#include "Inventory.h"
#include "EventSystem.h"
#include <map>
#include <vector>
#include <string>
#include <stack> 

class GameEngine {
public:
    void initGame();
    void runConsoleGame(); 

    // ========================================================
    // GUI CONNECTIONS (Required for GUI.cpp)
    // ========================================================
    WolfStats& getStats() { return currentStats; }
    StoryNode* getCurrentNode() { return currentNode; }

    // 1. LINK INVENTORY: Converts your Linked List to a Vector for the GUI
    std::vector<Item> getInventory() const { return inventory.toVector(); }
    
    // 2. LINK LOGS: Connects the "Notification Log" to the GUI Side Panel
    const std::vector<std::string>& getGameLog() const { return notificationLog; }
    
    // 3. LINK ACTIONS: Wrappers so GUI can call engine functions
    void processChoice(int choiceIndex) { makeChoice(choiceIndex); }
    
    // 4. LINK GAME STATE: Tells GUI if game is over/won
    bool isGameEnded() const { return gameOver; }
    bool isVictory() const { return currentStats.reputation >= 20; } // Example victory condition
    std::string getFinalTitle(); // Calculates Alpha/Lone Wolf

    // ========================================================
    // LOGIC HELPERS
    // ========================================================
    void makeChoice(int choiceIndex); 
    void useItem(int itemIndex);
    void triggerRandomEvent();
    
    void saveState(); 
    void undoLastAction(); 

private:
    std::map<int, StoryNode*> storyMap;
    StoryNode* currentNode;
    WolfStats currentStats;
    InventoryList inventory; 
    EventPriorityQueue eventQueue;

    // GUI DATA
    std::stack<GameState> historyStack; 
    std::vector<std::string> notificationLog; 

    bool gameOver = false;

    void addNode(int id, std::string text);
    void connect(int parentID, std::string choiceText, int childID);
    void addNotification(std::string msg); 
};

#endif