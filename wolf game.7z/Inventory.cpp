#include "Inventory.h"

InventoryList::InventoryList() {
    head = nullptr;
    itemCount = 0;
}

InventoryList::~InventoryList() {
    InventoryNode* current = head;
    while (current != nullptr) {
        InventoryNode* next = current->next;
        delete current;
        current = next;
    }
}

bool InventoryList::addItem(Item newItem) {
    // 1. Check for Stacking
    InventoryNode* current = head;
    while (current != nullptr) {
        if (current->data.name == newItem.name) {
            current->data.quantity += newItem.quantity;
            return true;
        }
        current = current->next;
    }

    // 2. Check Capacity
    if (itemCount >= MAX_ITEMS) {
        std::cout << "Inventory is full! Cannot pick up " << newItem.name << ".\n";
        return false;
    }

    // 3. Add New Node
    InventoryNode* newNode = new InventoryNode(newItem);
    if (head == nullptr) {
        head = newNode;
    } else {
        current = head;
        while (current->next != nullptr) {
            current = current->next;
        }
        current->next = newNode;
    }
    itemCount++;
    return true;
}

bool InventoryList::useItem(std::string itemName, WolfStats& stats) {
    InventoryNode* current = head;
    InventoryNode* prev = nullptr;

    while (current != nullptr) {
        if (current->data.name == itemName) {
            // Apply Effects
            if (current->data.type == FOOD) {
                stats.hunger -= current->data.effectValue;
                if (stats.hunger < 0) stats.hunger = 0;
                std::cout << "Ate " << itemName << ".\n";
            } else if (current->data.type == HERB) {
                stats.health += current->data.effectValue;
                if (stats.health > 100) stats.health = 100;
                std::cout << "Used " << itemName << ".\n";
            }
            
            // Reduce Quantity
            current->data.quantity--;
            if (current->data.quantity <= 0) {
                if (prev == nullptr) head = current->next;
                else prev->next = current->next;
                delete current;
                itemCount--;
            }
            return true;
        }
        prev = current;
        current = current->next;
    }
    return false;
}

void InventoryList::displayInventory() const {
    if (head == nullptr) {
        std::cout << " (Empty)\n";
        return;
    }
    InventoryNode* current = head;
    int index = 1;
    while (current != nullptr) {
        std::cout << " " << index << ". " << current->data.name << " (x" << current->data.quantity << ")\n";
        current = current->next;
        index++;
    }
}

// THIS IS THE FUNCTION YOUR ERROR SAYS IS MISSING
std::vector<Item> InventoryList::toVector() const {
    std::vector<Item> vec;
    InventoryNode* current = head;
    while (current != nullptr) {
        vec.push_back(current->data);
        current = current->next;
    }
    return vec;
}

// Helpers
bool InventoryList::hasItem(std::string itemName) const {
    InventoryNode* current = head;
    while (current != nullptr) {
        if (current->data.name == itemName) return true;
        current = current->next;
    }
    return false;
}

bool InventoryList::isFull() const {
    return itemCount >= MAX_ITEMS;
}

void InventoryList::removeItem(std::string itemName) {
    // Basic remove logic if needed for internal use
    InventoryNode* current = head;
    InventoryNode* prev = nullptr;
    while (current != nullptr) {
        if (current->data.name == itemName) {
            if (prev == nullptr) head = current->next;
            else prev->next = current->next;
            delete current;
            itemCount--;
            return;
        }
        prev = current;
        current = current->next;
    }
}