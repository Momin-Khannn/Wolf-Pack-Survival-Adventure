#include "GameEngine.cpp" 
#include "Inventory.cpp"
#include "EventSystem.cpp" // <--- ADDED THIS LINE

int main() {
    // Seed random number generator so events are different every time
    srand(time(0)); 

    GameEngine game;
    game.initGame();
    game.runConsoleGame();
    return 0;
}